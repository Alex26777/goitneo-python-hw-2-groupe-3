from collections import UserDict

class Field:
    # Базовий клас для полів запису.
    def __init__(self, value):
        self.value = value

    def __str__(self):
        return str(self.value)


class Name(Field):
    # Клас для зберігання імені контакту. Обов'язкове поле.
    pass


class Phone(Field):
    # Клас для зберігання номера телефону. Має валідацію формату (10 цифр).
    def __init__(self, value):
        if not value.isdigit() or len(value) != 10:
            raise ValueError("Номер телефону повинен складатися з 10 цифр")
        super().__init__(value)


class Record:
    # Клас для зберігання інформації про контакт, включаючи ім'я та список телефонів.
    def __init__(self, name):
        self.name = Name(name)
        self.phones = []

    def add_phone(self, phone):
        # Метод для додавання номеру телефону до контакту.
        self.phones.append(Phone(phone))

    def remove_phone(self, phone):
        # Метод для видалення номеру телефону з контакту.
        self.phones = [p for p in self.phones if p.value != phone]

    def edit_phone(self, old_phone, new_phone):
        # Метод для редагування існуючого номеру телефону.
        found_phone = self.find_phone(old_phone)
        if found_phone:
            found_phone.value = new_phone

    def find_phone(self, phone):
        # Метод для пошуку номеру телефону.
        for p in self.phones:
            if p.value == phone:
                return p
        return None

    def __str__(self):
        return f"Ім'я контакту: {self.name.value}, телефони: {'; '.join(p.value for p in self.phones)}"


class AddressBook(UserDict):
    # Клас для зберігання та управління записами.
    def add_record(self, record):
        # Метод для додавання запису до адресної книги.
        self.data[record.name.value] = record

    def find(self, name):
        # Метод для пошуку запису за іменем.
        return self.data.get(name)

    def delete(self, name):
        # Метод для видалення запису за іменем.
        if name in self.data:
            del self.data[name]

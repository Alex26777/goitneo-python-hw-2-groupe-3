def input_error(func):
    # Декоратор для обробки винятків у функціях
    def inner(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except ValueError:
            # Виняток для неправильного вводу значень
            return "Give me name and phone please."
        except KeyError:
            # Виняток, якщо ключ (ім'я) не знайдено
            return "No such contact."
        except IndexError:
            # Виняток, якщо не введено достатньо аргументів
            return "Provide enough arguments."
    return inner

@input_error
def add_contact(args, contacts):
    # Функція для додавання контакту
    name, phone = args
    contacts[name] = phone
    return "Contact added."

@input_error
def show_contact(args, contacts):
    # Функція для відображення інформації про контакт
    name = args[0]
    return f"{name}: {contacts[name]}"

@input_error
def delete_contact(args, contacts):
    # Функція для видалення контакту
    name = args[0]
    del contacts[name]
    return "Contact deleted."
